def diferencia(xa, ya, za, xc, yc, zc):
    dif_x = xa - xc
    dif_y = ya - yc
    dif_z = za - zc
    return dif_x, dif_y, dif_z

def producto_vectorial(x1, y1, z1, x2, y2, z2):
    pv1 = y1*z2 - z1*y2
    pv2 = z1*x2 - x1*z2 
    pv3 = x1*y2 - y1*x2
    return pv1, pv2, pv3

def area(x, y, z):
    return ((x**2 + y**2 + z**2) ** 0.5)/2