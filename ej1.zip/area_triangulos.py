import vectores

def area_triangulos(xa , ya , za , xb , yb , zb , xc , yc , zc):

    x1 , y1 , z1 = vectores.diferencia(xa, ya, za, xb, yb, zb)
    x2 , y2 , z2 = vectores.diferencia(xa, ya, za, xc, yc, zc)
    x , y , z = vectores.producto_vectorial(x1, y1, z1, x2, y2, z2)
    area_t = vectores.area(x, y, z)
    return area_t

assert area_triangulos(0,0,0,0,2,0,2,0,0) == 2
assert area_triangulos(7,2,0,7,12,0,17,0,0) == 50
assert area_triangulos(-3,8,0,-3,18,0,7,0,0) == 50
assert area_triangulos(5,-3,0,5,1,0,5,-3,4) == 8
assert area_triangulos(21,-17,4,21,-17,16,21,-5,4) == 72
